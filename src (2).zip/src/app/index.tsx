import { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { T } from '../constants/colors';

export default function SplashScreen() {
  useEffect(() => {
    (async () => {
      await new Promise(r => setTimeout(r, 1500));
      const token = await AsyncStorage.getItem('token').catch(() => null);
      router.replace(token ? '/main' : '/login');
    })();
  }, []);

  return (
    <View style={s.container}>
      {/* 로고 박스 */}
      <View style={s.logoBox}>
        <Text style={s.logoIcon}>🛴</Text>
      </View>
      <View style={s.textWrap}>
        <Text style={s.appName}>Safe Kick</Text>
        <Text style={s.appSub}>전동 킥보드 안전 인증 서비스</Text>
      </View>
      {/* 로딩 닷 */}
      <View style={s.dots}>
        {[0, 1, 2].map(i => (
          <View key={i} style={[s.dot, i === 1 && s.dotActive]} />
        ))}
      </View>
      <Text style={s.version}>v1.0.0</Text>
    </View>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: T.bg,
    alignItems: 'center', justifyContent: 'center', gap: 20,
  },
  logoBox: {
    width: 88, height: 88, borderRadius: 22,
    backgroundColor: T.fill,
    alignItems: 'center', justifyContent: 'center',
  },
  logoIcon: { fontSize: 44 },
  textWrap: { alignItems: 'center' },
  appName: { fontSize: 28, fontWeight: '700', color: T.text, letterSpacing: -0.5 },
  appSub: { fontSize: 13, color: T.textMuted, marginTop: 4 },
  dots: { flexDirection: 'row', gap: 6, marginTop: 24 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: T.fillMed },
  dotActive: { backgroundColor: T.text },
  version: {
    position: 'absolute', bottom: 48,
    fontSize: 11, color: T.textMuted, letterSpacing: 0.5,
  },
});
